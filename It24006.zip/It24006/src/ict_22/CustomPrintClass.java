package ict_22;

public class CustomPrintClass {
    public static void pr(String msg) {
        System.out.println(msg);
    }

}
