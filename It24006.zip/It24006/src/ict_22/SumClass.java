package ict_22;

public class SumClass {
    public static double calculateSum() {
        double sum = 0.0;
        for (double i = 1.0; i >= 0.01; i=i-0.1) {
            sum = sum+ i;
        }
        return Math.round(sum);
    }
}
