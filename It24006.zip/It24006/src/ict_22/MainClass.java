package ict_22;

public class MainClass {
    public static void main(String[] args) {

        CustomPrintClass.pr("===== PROGRAM STARTED =====");
        double sum = SumClass.calculateSum();
        CustomPrintClass.pr("Sum of 1 + 0.9 + ... + 0.1 = " + sum);
        int a = 12, b = 18;
        CustomPrintClass.pr("GCD of " + a + " and " + b + " = " + DivisorMultipleClass.gcd(a, b));
        CustomPrintClass.pr("LCM of " + a + " and " + b + " = " + DivisorMultipleClass.lcm(a, b));
        int dec = 25;
        CustomPrintClass.pr("Decimal " + dec + " -> Binary = " + NumberConversionClass.decimalToBinary(dec));
        CustomPrintClass.pr("Decimal " + dec + " -> Octal = " + NumberConversionClass.decimalToOctal(dec));
        CustomPrintClass.pr("Decimal " + dec + " -> Hexadecimal = " + NumberConversionClass.decimalToHex(dec));
        CustomPrintClass.pr("Binary 11001 -> Decimal = " + NumberConversionClass.binaryToDecimal("11001"));
        CustomPrintClass.pr("Octal 31 -> Decimal = " + NumberConversionClass.octalToDecimal("31"));
        CustomPrintClass.pr("Hex 19 -> Decimal = " + NumberConversionClass.hexToDecimal("19"));

        CustomPrintClass.pr("===== PROGRAM ENDED =====");
    }
}
